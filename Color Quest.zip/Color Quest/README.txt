Online Game - https://baunfire.itch.io/color-quest
GitHub - https://github.com/eandreae/120-Group-9

Notes: Our game crashed once in itch.io when we killed King Color. It never happened
before and it was very unusual. We tested this like 3 times after and it didn't crash, so
we have no idea why it crashed that one time.
