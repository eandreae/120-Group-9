<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="color_tiles_2" tilewidth="32" tileheight="32" tilecount="84" columns="7">
 <image source="../TileMaps/color_tiles_2.png" width="224" height="384"/>
</tileset>
